<?php
$producto = $_POST['inputProducto'] ?? '';
$cantidad = $_POST['inputCantidad'] ?? '';

// Crear el socket
$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
if ($socket === false) {
    die("No se pudo crear el socket: " . socket_strerror(socket_last_error()));
}

if (!socket_connect($socket, "127.0.0.1", 7080)) {
    die("No se pudo conectar al servidor: " . socket_strerror(socket_last_error($socket)));
}

// Preparar los datos en formato JSON
$pedido = json_encode([
    "producto" => $producto,
    "cantidad" => intval($cantidad)
]);

// Enviar los datos por el socket
socket_write($socket, $pedido, strlen($pedido));

// Recibir respuesta del servidor
$respuesta = socket_read($socket, 2048);

echo "Respuesta del servidor: $respuesta";

// Cerrar el socket
socket_close($socket);
?>