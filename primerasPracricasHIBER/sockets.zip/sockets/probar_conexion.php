<?php
header('Content-Type: application/json');
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $puerto = $_POST['inputPuerto'] ?? '';  // ✅ nombre correcto del input


    // Solo acepta el puerto correcto (ejemplo: 7080)
    if ($puerto === '7080') {
        echo json_encode(["success" => true, "message" => "conexion establecida"]);
    } else {
        echo json_encode(["success" => false, "message" => "Fallo de conexión: puerto incorrecto"]);
    }
    exit;
}
?>
