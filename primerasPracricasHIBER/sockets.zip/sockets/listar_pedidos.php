<?php
$mysqli = new mysqli("localhost", "root", "", "tienda");
$result = $mysqli->query("SELECT id, producto, cantidad, fecha FROM pedidos ORDER BY id DESC");
$pedidos = [];
while ($row = $result->fetch_assoc()) {
    $pedidos[] = $row;
}
header('Content-Type: application/json');
echo json_encode($pedidos);
?>