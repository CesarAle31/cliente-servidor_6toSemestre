<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verificamos qué formulario se envió
    $tipoFormulario = $_POST['formulario'] ?? '';

    if ($tipoFormulario === 'conexion') {
        // Procesar formulario de conexión
        $ip = $_POST['inputIP'] ?? '127.0.0.1';
        $puerto = $_POST['inputPuerto'] ?? 7080;

        echo "Conectado a: $ip:$puerto";
        // Aquí podrías guardar la IP y el puerto en sesión si quieres usarlo después
        // session_start();
        // $_SESSION['ip'] = $ip;
        // $_SESSION['puerto'] = $puerto;

    } elseif ($tipoFormulario === 'pedido') {
        // Procesar formulario de pedido
        $producto = $_POST['inputProducto'] ?? '';
        $cantidad = $_POST['inputCantidad'] ?? 0;

        // Puedes usar IP/puerto por defecto o recuperarlo de la sesión si lo guardaste antes
        $ip = '127.0.0.1';
        $puerto = 7080;

        // Crear el socket
        $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        if ($socket === false) {
            die("Error al crear el socket: " . socket_strerror(socket_last_error()));
        }

        // Conectar al servidor
        $result = socket_connect($socket, $ip, $puerto);
        if ($result === false) {
            die("No se pudo conectar al servidor: " . socket_strerror(socket_last_error($socket)));
        }

        // Enviar datos como JSON
        $pedido = json_encode([
            "producto" => $producto,
            "cantidad" => (int)$cantidad
        ]);
        socket_write($socket, $pedido, strlen($pedido));

        // Leer respuesta del servidor
        $respuesta = socket_read($socket, 2048);
        echo "Respuesta del servidor: " . htmlspecialchars($respuesta);

        socket_close($socket);
    } else {
        echo "Formulario no reconocido.";
    }
}
?>
