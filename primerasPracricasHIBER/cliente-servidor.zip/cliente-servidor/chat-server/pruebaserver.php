<?php

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require dirname(__DIR__) . '/vendor/autoload.php';

class ChatServer implements MessageComponentInterface
{
    protected $clients;
    protected $db;
    protected $usuarios = []; // resourceId => ['id'=>, 'nombre'=>, 'rol'=>, 'asistencia_id'=>, 'online'=>]

    public function __construct()
    {
        $this->clients = new \SplObjectStorage;
        $this->db = new PDO('mysql:host=localhost;dbname=chat;charset=utf8mb4', 'root', '');
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function onOpen(ConnectionInterface $conn)
    {
        $this->clients->attach($conn);
    }

    public function onMessage(ConnectionInterface $from, $msg)
    {
        $data = json_decode($msg, true);
        if (!$data) return;

        // Autenticación docente
        if (isset($data['action']) && $data['action'] === "auth" && $data['rol'] === "maestro") {
            $this->usuarios[$from->resourceId] = [
                'id' => $data['id_usuario'],
                'nombre' => 'DOCENTE',
                'rol' => 'maestro',
                'asistencia_id' => null,
                'online' => true
            ];
            $from->send(json_encode([
                "type" => "sistema",
                "msg" => "Autenticado como docente"
            ]));
            // Envía la lista y preguntas iniciales
            $from->send(json_encode([
                'type' => 'lista',
                'lista' => $this->getListaAlumnos()
            ]));
            $from->send(json_encode([
                'type' => 'preguntas',
                'preguntas' => $this->getPreguntas()
            ]));
            return;
        }

        // Panel docente pide lista de alumnos manualmente
        if (isset($data['action']) && $data['action'] === "get_lista") {
            $from->send(json_encode([
                'type' => 'lista',
                'lista' => $this->getListaAlumnos()
            ]));
            return;
        }

        // Panel docente pide preguntas manualmente
        if (isset($data['action']) && $data['action'] === "get_preguntas") {
            $from->send(json_encode([
                'type' => 'preguntas',
                'preguntas' => $this->getPreguntas()
            ]));
            return;
        }

        // Evento de alumno: ENTRADA
        if (isset($data['type']) && $data['type'] === "entrada") {
            $usuario = $this->getUsuarioPorNombre($data['usuario']);
            if (!$usuario) {
                $from->send(json_encode(['type' => 'error', 'msg' => "Usuario no encontrado"]));
                return;
            }

            // INSERT: Nueva asistencia (nuevo registro cada vez que entra)
            $stmt = $this->db->prepare("INSERT INTO asistencia (id_usuario, hora_entrada) VALUES (?, NOW())");
            $stmt->execute([$usuario['id']]);
            $asistencia_id = $this->db->lastInsertId();

            $this->usuarios[$from->resourceId] = [
                'id' => $usuario['id'],
                'nombre' => $usuario['nombre'],
                'rol' => $usuario['rol'],
                'asistencia_id' => $asistencia_id,
                'online' => true
            ];

            // Enviar historial de preguntas solo al alumno que entra
            $from->send(json_encode([
                'type' => 'preguntas_historial',
                'preguntas' => $this->getPreguntas()
            ]));

            $this->broadcastLista();
            $this->broadcastConectados();
            return;
        }

        // Evento de alumno: SALIDA
        if (isset($data['type']) && $data['type'] === "salida") {
            if (isset($this->usuarios[$from->resourceId]['asistencia_id'])) {
                $stmt = $this->db->prepare("UPDATE asistencia SET hora_salida=NOW() WHERE id=?");
                $stmt->execute([$this->usuarios[$from->resourceId]['asistencia_id']]);
            }
            if (isset($this->usuarios[$from->resourceId])) {
                $this->usuarios[$from->resourceId]['online'] = false;
            }
            $this->broadcastLista();
            $this->broadcastConectados();
            return;
        }

        // Evento de alumno: PREGUNTA
        if (isset($data['type']) && $data['type'] === "pregunta") {
            if (!isset($this->usuarios[$from->resourceId])) return;
            $id_usuario = $this->usuarios[$from->resourceId]['id'];
            $pregunta = $data['pregunta'];
            $stmt = $this->db->prepare("INSERT INTO mensajes (id_usuario, mensaje, hora) VALUES (?, ?, NOW())");
            $stmt->execute([$id_usuario, $pregunta]);

            // Broadcast a todos: nueva pregunta
            $nombre = $this->usuarios[$from->resourceId]['nombre'];
            $payload = json_encode([
                'type' => 'pregunta',
                'usuario' => $nombre,
                'pregunta' => $pregunta
            ]);
            foreach ($this->clients as $client) {
                $client->send($payload);
            }
            // Actualiza la lista de preguntas para todos
            $this->broadcastPreguntas();
            return;
        }
    }

    public function onClose(ConnectionInterface $conn)
    {
        if (isset($this->usuarios[$conn->resourceId])) {
            if (isset($this->usuarios[$conn->resourceId]['asistencia_id'])) {
                $stmt = $this->db->prepare("UPDATE asistencia SET hora_salida=NOW() WHERE id=?");
                $stmt->execute([$this->usuarios[$conn->resourceId]['asistencia_id']]);
            }
            $this->usuarios[$conn->resourceId]['online'] = false;
            unset($this->usuarios[$conn->resourceId]);
        }
        $this->clients->detach($conn);
        $this->broadcastLista();
        $this->broadcastConectados();
    }

    public function onError(ConnectionInterface $conn, \Exception $e)
    {
        $conn->close();
    }

    // ---------- FUNCIONES DE AYUDA ----------
    private function getUsuarioPorNombre($nombre)
    {
        $stmt = $this->db->prepare("SELECT * FROM usuarios WHERE nombre=? LIMIT 1");
        $stmt->execute([$nombre]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    private function getListaAlumnos()
    {
        $sql = "SELECT u.id, u.nombre FROM usuarios u WHERE u.rol='alumno' ORDER BY u.nombre";
        $stmt = $this->db->query($sql);
        $alumnos = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            // Estado online en memoria
            $online = false;
            foreach ($this->usuarios as $info) {
                if ($info['id'] == $row['id'] && $info['online']) {
                    $online = true;
                    break;
                }
            }
            // Última asistencia
            $stmt2 = $this->db->prepare("SELECT hora_entrada, hora_salida FROM asistencia WHERE id_usuario=? ORDER BY id DESC LIMIT 1");
            $stmt2->execute([$row['id']]);
            $asis = $stmt2->fetch(PDO::FETCH_ASSOC);

            $alumnos[] = [
                'nombre' => $row['nombre'],
                'online' => $online,
                'hora_entrada' => $asis ? $asis['hora_entrada'] : '-',
                'hora_salida' => $asis ? $asis['hora_salida'] : '-'
            ];
        }
        return $alumnos;
    }

    private function getPreguntas($limite = 30)
    {
        $stmt = $this->db->prepare(
            "SELECT u.nombre as usuario, m.mensaje as pregunta, m.hora FROM mensajes m 
            JOIN usuarios u ON u.id = m.id_usuario 
            ORDER BY m.hora DESC LIMIT ?"
        );
        $stmt->bindValue(1, $limite, PDO::PARAM_INT);
        $stmt->execute();
        return array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC)); // Más antiguas primero
    }

    private function broadcastLista()
    {
        $lista = $this->getListaAlumnos();
        $payload = json_encode([
            'type' => 'lista',
            'lista' => $lista
        ]);
        foreach ($this->clients as $client) {
            $client->send($payload);
        }
    }

    private function broadcastPreguntas()
    {
        $preguntas = $this->getPreguntas();
        $payload = json_encode([
            'type' => 'preguntas',
            'preguntas' => $preguntas
        ]);
        foreach ($this->clients as $client) {
            $client->send($payload);
        }
    }

    private function broadcastConectados()
    {
        $conectados = [];
        foreach ($this->usuarios as $info) {
            if ($info['online']) {
                $conectados[] = $info['nombre'];
            }
        }
        $payload = json_encode([
            'type' => 'conectados',
            'usuarios' => $conectados
        ]);
        foreach ($this->clients as $client) {
            $client->send($payload);
        }
    }
}

// Ejecutar el servidor
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new ChatServer()
        )
    ),
    8081 // Cambia el puerto si lo necesitas
);

$server->run();
