<?php
require dirname(__DIR__) . '/vendor/autoload.php';

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

class Chat implements MessageComponentInterface {
    protected $clients;
    private $mysqli;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
        // Ajusta los datos de conexión según tu entorno
        $this->mysqli = new mysqli('localhost', 'root', '', 'chat');
        if ($this->mysqli->connect_error) {
            die('Error de conexión a la base de datos');
        }
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);

        if (!$data || !isset($data['type'])) {
            $from->send(json_encode([
                'type' => 'register',
                'success' => false,
                'error' => 'Datos inválidos'
            ]));
            return;
        }

        if ($data['type'] === 'register') {
            $nombre = $this->mysqli->real_escape_string($data['nombre'] ?? '');
            $correo = $this->mysqli->real_escape_string($data['correo'] ?? '');
            $contraseña = $data['contraseña'] ?? '';
            $rol = $this->mysqli->real_escape_string($data['rol'] ?? '');

            if (!$nombre || !$correo || !$contraseña || !$rol) {
                $from->send(json_encode([
                    'type' => 'register',
                    'success' => false,
                    'error' => 'Faltan campos'
                ]));
                return;
            }

            // Verifica si el correo ya existe
            $stmt = $this->mysqli->prepare("SELECT id FROM usuarios WHERE correo = ?");
            $stmt->bind_param("s", $correo);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $from->send(json_encode([
                    'type' => 'register',
                    'success' => false,
                    'error' => 'El correo ya está registrado'
                ]));
                $stmt->close();
                return;
            }
            $stmt->close();

            // Hashea la contraseña
            $hashed = password_hash($contraseña, PASSWORD_DEFAULT);

            // Inserta el usuario
            $stmt = $this->mysqli->prepare("INSERT INTO usuarios (nombre, correo, contraseña, rol) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nombre, $correo, $hashed, $rol);

            if ($stmt->execute()) {
                $from->send(json_encode([
                    'type' => 'register',
                    'success' => true
                ]));
            } else {
                $from->send(json_encode([
                    'type' => 'register',
                    'success' => false,
                    'error' => 'Error al registrar usuario'
                ]));
            }
            $stmt->close();
        }
        // Aquí puedes agregar el manejo de login si lo deseas
        if ($data['type'] === 'login') {
            $correo = $this->mysqli->real_escape_string($data['correo'] ?? '');
            $contraseña = $data['contraseña'] ?? '';

            if (!$correo || !$contraseña) {
                $from->send(json_encode([
                    'type' => 'login',
                    'success' => false,
                    'error' => 'Faltan campos'
                ]));
                return;
            }

            $stmt = $this->mysqli->prepare("SELECT contraseña, rol FROM usuarios WHERE correo = ?");
            $stmt->bind_param("s", $correo);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows === 1) {
                $stmt->bind_result($hashed, $rol);
                $stmt->fetch();

                if (password_verify($contraseña, $hashed)) {
                    $from->send(json_encode([
                        'type' => 'login',
                        'success' => true,
                        'rol' => $rol
                    ]));
                } else {
                    $from->send(json_encode([
                        'type' => 'login',
                        'success' => false,
                        'error' => 'Contraseña incorrecta'
                    ]));
                }
            } else {
                $from->send(json_encode([
                    'type' => 'login',
                    'success' => false,
                    'error' => 'Correo no encontrado'
                ]));
            }
            $stmt->close();
        }




    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        $conn->close();
    }
}

use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new Chat()
        )
    ),
    8080
);

echo "WebSocket server running on ws://localhost:8080\n";
$server->run();