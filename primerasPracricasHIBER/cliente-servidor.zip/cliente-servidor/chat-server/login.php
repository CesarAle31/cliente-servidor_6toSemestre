<?php
header('Content-Type: application/json');
$data = json_decode(file_get_contents('php://input'), true);

$correo = $data['correo'] ?? '';
$password = $data['password'] ?? '';

// Conecta a la base de datos
$db = new PDO('mysql:host=localhost;dbname=chat;charset=utf8mb4', 'root', '');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Verifica el usuario
$stmt = $db->prepare('SELECT id, nombre, contraseña, rol FROM usuarios WHERE correo=? LIMIT 1');
$stmt->execute([$correo]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user['contraseña'])) {
    echo json_encode([
        'success' => true,
        'rol' => $user['rol'],
        'nombre' => $user['nombre'],
        'id' => $user['id']
    ]);
} else {
    echo json_encode(['success' => false]);
}