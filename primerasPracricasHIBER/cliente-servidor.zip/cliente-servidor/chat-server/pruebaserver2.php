<?php
//use Ratchet\MessageComponentInterface;
//use Ratchet\ConnectionInterface;
//
//require dirname(__DIR__) . '/vendor/autoload.php';
//
//class AulaServer implements MessageComponentInterface {
//    protected $clients;
//    protected $db;
//    protected $usuarios = []; // resourceId => ['id'=>, 'nombre'=>, 'rol'=>, 'asistencia_id'=>, 'online'=>]
//
//    public function __construct() {
//        $this->clients = new \SplObjectStorage;
//        $this->db = new PDO('mysql:host=localhost;dbname=chat;charset=utf8mb4', 'root', '');
//        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
//    }
//
//    public function onOpen(ConnectionInterface $conn) {
//        $this->clients->attach($conn);
//    }
//
//    public function onMessage(ConnectionInterface $from, $msg) {
//        $data = json_decode($msg, true);
//        if (!$data) return;
//
//        // Autenticación docente
//        if ($data['action'] === "auth" && $data['rol'] === "maestro") {
//            $this->usuarios[$from->resourceId] = [
//                'id' => $data['id_usuario'],
//                'nombre' => 'DOCENTE',
//                'rol' => 'maestro',
//                'asistencia_id' => null,
//                'online' => true
//            ];
//            // Opcional: puedes guardar conexión docente si necesitas hacer push después
//            $from->send(json_encode([
//                "type" => "sistema",
//                "msg" => "Autenticado como docente"
//            ]));
//            return;
//        }
//
//        // Panel docente pide lista
//        if ($data['action'] === "get_lista") {
//            $from->send(json_encode([
//                'type' => 'lista',
//                'lista' => $this->getListaAlumnos()
//            ]));
//            return;
//        }
//
//        // Panel docente pide preguntas
//        if ($data['action'] === "get_preguntas") {
//            $from->send(json_encode([
//                'type' => 'preguntas',
//                'preguntas' => $this->getPreguntas()
//            ]));
//            return;
//        }
//
//        // --- Eventos de alumnos (no docente) ---
//        if ($data['type'] === "entrada") {
//            error_log("Entrada recibida para usuario: " . $data['usuario']);
//            // Busca usuario en base
//            $usuario = $this->getUsuarioPorNombre($data['usuario']);
//            if (!$usuario) {
//                $from->send(json_encode(['type'=>'error','msg'=>"Usuario no encontrado"]));
//                return;
//            }
//            $this->usuarios[$from->resourceId] = [
//                'id' => $usuario['id'],
//                'nombre' => $usuario['nombre'],
//                'rol' => $usuario['rol'],
//                'online' => true
//            ];
//            // Inserta asistencia
//            $stmt = $this->db->prepare("INSERT INTO asistencia (id_usuario, hora_entrada) VALUES (?, NOW())");
//            $stmt->execute([$usuario['id']]);
//            $asistencia_id = $this->db->lastInsertId();
//            $this->usuarios[$from->resourceId]['asistencia_id'] = $asistencia_id;
//
//            $this->broadcastLista();
//        }
//
//        if ($data['type'] === "salida") {
//            if (isset($this->usuarios[$from->resourceId]['asistencia_id'])) {
//                $stmt = $this->db->prepare("UPDATE asistencia SET hora_salida=NOW() WHERE id=?");
//                $stmt->execute([$this->usuarios[$from->resourceId]['asistencia_id']]);
//            }
//            if (isset($this->usuarios[$from->resourceId])) {
//                $this->usuarios[$from->resourceId]['online'] = false;
//            }
//            $this->broadcastLista();
//        }
//
//        if ($data['type'] === "pregunta") {
//            if (!isset($this->usuarios[$from->resourceId])) return;
//            $id_usuario = $this->usuarios[$from->resourceId]['id'];
//            $pregunta = $data['pregunta'];
//            $stmt = $this->db->prepare("INSERT INTO mensajes (id_usuario, mensaje, hora) VALUES (?, ?, NOW())");
//            $stmt->execute([$id_usuario, $pregunta]);
//            $nombre = $this->usuarios[$from->resourceId]['nombre'];
//            $payload = [
//                'type' => 'pregunta',
//                'usuario' => $nombre,
//                'pregunta' => $pregunta,
//                'hora' => date('Y-m-d H:i:s')
//            ];
//            // Broadcast pregunta a todos (incluye docente)
//            foreach ($this->clients as $client) {
//                $client->send(json_encode($payload));
//            }
//            $this->broadcastPreguntas();
//        }
//    }
//
//    public function onClose(ConnectionInterface $conn) {
//        // Si era alumno, marca salida y desconectado
//        if (isset($this->usuarios[$conn->resourceId])) {
//            if (isset($this->usuarios[$conn->resourceId]['asistencia_id'])) {
//                $stmt = $this->db->prepare("UPDATE asistencia SET hora_salida=NOW() WHERE id=?");
//                $stmt->execute([$this->usuarios[$conn->resourceId]['asistencia_id']]);
//            }
//            $this->usuarios[$conn->resourceId]['online'] = false;
//            $this->broadcastLista();
//            unset($this->usuarios[$conn->resourceId]);
//        }
//        $this->clients->detach($conn);
//    }
//
//    public function onError(ConnectionInterface $conn, \Exception $e) {
//        $conn->close();
//    }
//
//    // ---------- FUNCIONES DE AYUDA ----------
//    private function getUsuarioPorNombre($nombre) {
//        $stmt = $this->db->prepare("SELECT * FROM Usuarios WHERE nombre=? LIMIT 1");
//        $stmt->execute([$nombre]);
//        return $stmt->fetch(PDO::FETCH_ASSOC);
//    }
//
//    private function getListaAlumnos() {
//        // Trae todos los alumnos (aunque nunca hayan tenido asistencia)
//        $sql = "SELECT u.id, u.nombre FROM usuarios u WHERE u.rol='alumno' ORDER BY u.nombre";
//        $stmt = $this->db->query($sql);
//        $alumnos = [];
//        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
//            // Verifica estado online en memoria
//            $online = false;
//            foreach ($this->usuarios as $info) {
//                if ($info['id'] == $row['id'] && $info['online']) {
//                    $online = true;
//                    break;
//                }
//            }
//
//            // Busca última asistencia
//            $stmt2 = $this->db->prepare("SELECT hora_entrada, hora_salida FROM asistencia WHERE id_usuario=? ORDER BY id DESC LIMIT 1");
//            $stmt2->execute([$row['id']]);
//            $asis = $stmt2->fetch(PDO::FETCH_ASSOC);
//
//            $alumnos[] = [
//                'nombre' => $row['nombre'],
//                'online' => $online,
//                'hora_entrada' => $asis ? $asis['hora_entrada'] : '-',
//                'hora_salida' => $asis ? $asis['hora_salida'] : '-'
//            ];
//        }
//        return $alumnos;
//    }
//
//    private function getPreguntas($limite=30) {
//        $stmt = $this->db->prepare("
//            SELECT U.nombre as username, M.mensaje as text, M.hora
//            FROM mensajes M
//            JOIN Usuarios U ON U.id = M.id_usuario
//            ORDER BY M.hora DESC
//            LIMIT ?
//        ");
//        $stmt->bindValue(1, $limite, PDO::PARAM_INT);
//        $stmt->execute();
//        return array_reverse($stmt->fetchAll(PDO::FETCH_ASSOC));
//    }
//
//    private function broadcastLista() {
//        $lista = $this->getListaAlumnos();
//        foreach ($this->clients as $client) {
//            $client->send(json_encode([
//                'type' => 'lista',
//                'lista' => $lista
//            ]));
//        }
//    }
//
//    private function broadcastPreguntas() {
//        $preguntas = $this->getPreguntas();
//        foreach ($this->clients as $client) {
//            $client->send(json_encode([
//                'type' => 'preguntas',
//                'preguntas' => $preguntas
//            ]));
//        }
//    }
//}
//
//// Servidor WebSocket
//use Ratchet\Server\IoServer;
//use Ratchet\Http\HttpServer;
//use Ratchet\WebSocket\WsServer;
//
//$server = IoServer::factory(
//    new HttpServer(
//        new WsServer(
//            new AulaServer()
//        )
//    ),
//    8082 // Puerto
//);
//
//$server->run();


use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require dirname(__DIR__) . '/vendor/autoload.php';

class ChatServer implements MessageComponentInterface
{
    protected $clients;
    protected $db;
    protected $usuarios = []; // resourceId => ['id'=>, 'nombre'=>, 'rol'=>, 'asistencia_id'=>, 'online'=>]

    public function __construct()
    {
        $this->clients = new \SplObjectStorage;
        $this->db = new PDO('mysql:host=localhost;dbname=chat;charset=utf8mb4', 'root', '');
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function onOpen(ConnectionInterface $conn)
    {
        $this->clients->attach($conn);
    }

    public function onMessage(ConnectionInterface $from, $msg)
    {
        $data = json_decode($msg, true);
        if (!$data) return;

        // Autenticación docente
        if (isset($data['action']) && $data['action'] === "auth" && $data['rol'] === "maestro") {
            $this->usuarios[$from->resourceId] = [
                'id' => $data['id_usuario'],
                'nombre' => 'DOCENTE',
                'rol' => 'maestro',
                'asistencia_id' => null,
                'online' => true
            ];
            $from->send(json_encode([
                "type" => "sistema",
                "msg" => "Autenticado como docente"
            ]));
            // Envía la lista y preguntas iniciales
            $from->send(json_encode([
                'type' => 'lista',
                'lista' => $this->getListaAlumnos()
            ]));
            $from->send(json_encode([
                'type' => 'preguntas',
                'preguntas' => $this->getPreguntas()
            ]));
            return;
        }

        // Panel docente pide lista de alumnos manualmente
        if (isset($data['action']) && $data['action'] === "get_lista") {
            $from->send(json_encode([
                'type' => 'lista',
                'lista' => $this->getListaAlumnos()
            ]));
            return;
        }

        // Panel docente pide preguntas manualmente
        if (isset($data['action']) && $data['action'] === "get_preguntas") {
            $from->send(json_encode([
                'type' => 'preguntas',
                'preguntas' => $this->getPreguntas()
            ]));
            return;
        }

        // Evento de alumno: ENTRADA
        if (isset($data['type']) && $data['type'] === "entrada") {
            $usuario = $this->getUsuarioPorNombre($data['usuario']);
            if (!$usuario) {
                $from->send(json_encode(['type' => 'error', 'msg' => "Usuario no encontrado"]));
                return;
            }

            // INSERT: Nueva asistencia (nuevo registro cada vez que entra)
            $stmt = $this->db->prepare("INSERT INTO asistencia (id_usuario, hora_entrada) VALUES (?, NOW())");
            $stmt->execute([$usuario['id']]);
            $asistencia_id = $this->db->lastInsertId();

            $this->usuarios[$from->resourceId] = [
                'id' => $usuario['id'],
                'nombre' => $usuario['nombre'],
                'rol' => $usuario['rol'],
                'asistencia_id' => $asistencia_id,
                'online' => true
            ];

            $this->broadcastLista(); // Actualiza en tiempo real la lista de alumnos
            return;
        }

        // Evento de alumno: SALIDA
        if (isset($data['type']) && $data['type'] === "salida") {
            if (isset($this->usuarios[$from->resourceId]['asistencia_id'])) {
                $stmt = $this->db->prepare("UPDATE asistencia SET hora_salida=NOW() WHERE id=?");
                $stmt->execute([$this->usuarios[$from->resourceId]['asistencia_id']]);
            }
            if (isset($this->usuarios[$from->resourceId])) {
                $this->usuarios[$from->resourceId]['online'] = false;
            }
            $this->broadcastLista(); // Actualiza en tiempo real la lista de alumnos
            return;
        }

        // Evento de alumno: PREGUNTA
        if (isset($data['type']) && $data['type'] === "pregunta") {
            if (!isset($this->usuarios[$from->resourceId])) return;
            $id_usuario = $this->usuarios[$from->resourceId]['id'];
            $pregunta = $data['pregunta'];
            $stmt = $this->db->prepare("INSERT INTO mensajes (id_usuario, mensaje, hora) VALUES (?, ?, NOW())");
            $stmt->execute([$id_usuario, $pregunta]);
            $this->broadcastPreguntas(); // Actualiza en tiempo real la lista de preguntas
            return;
        }
    }

    public function onClose(ConnectionInterface $conn)
    {
        // Si era alumno, marca salida y desconectado
        if (isset($this->usuarios[$conn->resourceId])) {
            if (isset($this->usuarios[$conn->resourceId]['asistencia_id'])) {
                $stmt = $this->db->prepare("UPDATE asistencia SET hora_salida=NOW() WHERE id=?");
                $stmt->execute([$this->usuarios[$conn->resourceId]['asistencia_id']]);
            }
            $this->usuarios[$conn->resourceId]['online'] = false;
            unset($this->usuarios[$conn->resourceId]);
        }
        $this->clients->detach($conn);
        $this->broadcastLista();
    }

    public function onError(ConnectionInterface $conn, \Exception $e)
    {
        $conn->close();
    }

    // ---------- FUNCIONES DE AYUDA ----------
    private function getUsuarioPorNombre($nombre)
    {
        $stmt = $this->db->prepare("SELECT * FROM usuarios WHERE nombre=? LIMIT 1");
        $stmt->execute([$nombre]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    private function getListaAlumnos()
    {
        $sql = "SELECT u.id, u.nombre FROM usuarios u WHERE u.rol='alumno' ORDER BY u.nombre";
        $stmt = $this->db->query($sql);
        $alumnos = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            // Estado online en memoria
            $online = false;
            foreach ($this->usuarios as $info) {
                if ($info['id'] == $row['id'] && $info['online']) {
                    $online = true;
                    break;
                }
            }
            // Última asistencia
            $stmt2 = $this->db->prepare("SELECT hora_entrada, hora_salida FROM asistencia WHERE id_usuario=? ORDER BY id DESC LIMIT 1");
            $stmt2->execute([$row['id']]);
            $asis = $stmt2->fetch(PDO::FETCH_ASSOC);

            $alumnos[] = [
                'nombre' => $row['nombre'],
                'online' => $online,
                'hora_entrada' => $asis ? $asis['hora_entrada'] : '-',
                'hora_salida' => $asis ? $asis['hora_salida'] : '-'
            ];
        }
        return $alumnos;
    }

    private function getPreguntas()
    {
        $stmt = $this->db->query("SELECT u.nombre as username, m.mensaje as text, m.hora FROM mensajes m JOIN usuarios u ON u.id = m.id_usuario ORDER BY m.hora DESC LIMIT 30");
        $preguntas = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return array_reverse($preguntas); // Más antiguas primero
    }

    private function broadcastLista()
    {
        $lista = $this->getListaAlumnos();
        $payload = json_encode([
            'type' => 'lista',
            'lista' => $lista
        ]);
        foreach ($this->clients as $client) {
            $client->send($payload);
        }
    }

    private function broadcastPreguntas()
    {
        $preguntas = $this->getPreguntas();
        $payload = json_encode([
            'type' => 'preguntas',
            'preguntas' => $preguntas
        ]);
        foreach ($this->clients as $client) {
            $client->send($payload);
        }
    }
}

// Ejecutar el servidor
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new ChatServer()
        )
    ),
    8082 // Cambia el puerto si lo necesitas
);

$server->run();