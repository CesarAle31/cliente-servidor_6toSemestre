<?php


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ip = $_POST['inputIP'] ?? '127.0.0.1';
    $puerto = $_POST['inputPuerto'] ?? 7080;
    $producto = $_POST['inputProducto'] ?? '';
    $cantidad = $_POST['inputCantidad'] ?? '';

    $pedido = [
        'producto' => $producto,
        'cantidad' => $cantidad
    ];

    $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
    if ($socket === false) {
        die("Error al crear socket: " . socket_strerror(socket_last_error()));
    }

    $result = socket_connect($socket, $ip, $puerto);
    if ($result === false) {
        die("Error al conectar al socket: " . socket_strerror(socket_last_error($socket)));
    }

    $json = json_encode($pedido);
    socket_write($socket, $json, strlen($json));

    // Leer respuesta del servidor
    $respuesta = socket_read($socket, 2048);
    socket_close($socket);

    // Muestra la respuesta al usuario
    echo "<h2>Respuesta del servidor:</h2>";
    echo "<pre>" . htmlspecialchars($respuesta) . "</pre>";
    echo "<a href='PaginaCliente.php'>Volver</a>";
}
?>