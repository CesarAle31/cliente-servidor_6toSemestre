<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>

    <title>Pagina_Cliente</title>
</head>
<body>
<div class="container col-md-6 offset-3">
    <br><br><br>
    <h1><center>Cliente</center></h1>
    <br><br>
    <form action="probar_conexion.php" method="POST">

        <div class="mb-3 row">
            <label for="inputIP" class="col-sm-2 col-form-label">IP</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="inputIP" name="inputIP">
            </div>
        </div>

        <div class="mb-3 row">
            <label for="inputPuerto" class="col-sm-2 col-form-label">Puerto</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="inputPuerto" name="inputPuerto">
            </div>
        </div>
        <div class="mb-4 row">
            <div class="col-sm-10 offset-sm-2">
                <button type="submit" class="btn btn-primary">Conectar</button>
            </div>
        </div>

    </form>
</div>
<div class="container col-md-6 offset-3">
    <br><br><br>
    <h1><center>Pedidos</center></h1>
    <br><br>

    <form id="formPedido" action="enviar_pedido.php" method="POST">
        <div class="mb-3 row">
            <label for="inputProducto" class="col-sm-2 col-form-label">Producto</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="inputProducto" name="inputProducto" disabled>
            </div>
        </div>
        <div class="mb-3 row">
            <label for="inputCantidad" class="col-sm-2 col-form-label">Cantidad</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="inputCantidad" name="inputCantidad" disabled>
            </div>
        </div>
        <div class="mb-4 row">
            <div class="col-sm-10 offset-sm-2">
                <button type="submit" class="btn btn-primary" disabled id="btnEnviarPedido">Enviar</button>
            </div>
        </div>
    </form>
</div>

<script>
    document.querySelector('form[action="probar_conexion.php"]').addEventListener('submit', function (e) {
        e.preventDefault(); // Evita recarga

        const ip = document.getElementById('inputIP').value;
        const puerto = document.getElementById('inputPuerto').value;

        fetch('probar_conexion.php', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: `inputPuerto=${encodeURIComponent(puerto)}&inputIP=${encodeURIComponent(ip)}`
        })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);

                    // Habilitar sección de pedidos
                    document.getElementById('inputProducto').disabled = false;
                    document.getElementById('inputCantidad').disabled = false;
                    document.getElementById('btnEnviarPedido').disabled = false;
                } else {
                    alert(data.message);
                }
            })
            .catch(err => {
                alert("Error al conectar con el servidor");
                console.error(err);
            });
    });
</script>



</body>
</html>