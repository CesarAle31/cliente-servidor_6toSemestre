
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>

    <title>Pagina_Servidor</title>
</head>
<body>



<div class="container col-md-6 offset-3">
    <br><br><br>
    <h1><center>Servidor</center></h1>
    <br><br>
<!--    <form action="probar_conexion.php" method="post">-->
    <form id="formConexion" action="probar_conexion.php" method="post">

        <div class="mb-3 row">
            <label for="inputPuerto" class="col-sm-2 col-form-label">Puerto</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="inputPuerto" name="inputPuerto">
            </div>
        </div>
        <div class="mb-4 row">
            <div class="col-sm-10 offset-sm-2">
                <button type="submit" class="btn btn-primary">Conectar</button>
                <br><br>
                <input type="text" class="form-control" id="inputRespuesta" name="inputRespuesta" value="esperando conexion..." readonly>
            </div>
        </div>
    </form>
</div>
<br>
<script>
    let isConnected = false;
    let intervalPedidos = null;
    document.getElementById('formConexion').onsubmit = function(e) {
        e.preventDefault();
        const puerto = document.getElementById('inputPuerto').value;

        fetch('probar_conexion.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: new URLSearchParams({ inputPuerto: puerto })
        })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    document.getElementById('inputRespuesta').value = data.message;
                    isConnected = true;
                    document.getElementById('tablaPedidos').style.pointerEvents = 'auto';
                    document.getElementById('tablaPedidos').style.opacity = '1';
                    cargarPedidos(); // carga la tabla inmediatamente
                    if (intervalPedidos) clearInterval(intervalPedidos);
                    intervalPedidos = setInterval(cargarPedidos, 3000); // solo aquí activas el intervalo
                } else {
                    document.getElementById('inputRespuesta').value = data.message;
                    isConnected = false;
                    document.getElementById('tablaPedidos').style.pointerEvents = 'none';
                    document.getElementById('tablaPedidos').style.opacity = '0.5';
                    document.getElementById('tabla-pedidos').innerHTML = '';
                    if (intervalPedidos) clearInterval(intervalPedidos);
                }
            })
            .catch(err => {
                document.getElementById('inputRespuesta').value = 'Error de conexión (AJAX)';
                isConnected = false;
                document.getElementById('tablaPedidos').style.pointerEvents = 'none';
                document.getElementById('tablaPedidos').style.opacity = '0.5';
                document.getElementById('tabla-pedidos').innerHTML = '';
                if (intervalPedidos) clearInterval(intervalPedidos);
            });
    };
</script>
<h2><center>Pedidos</center></h2>
<br>
<center>
<!--<table class="table table-striped-columns">-->
    <table class="table table-striped-columns" id="tablaPedidos" style="pointer-events: none; opacity:0.5;">
    <thead>
    <tr>
        <th scope="col">ID</th>
        <th scope="col">Productos</th>
        <th scope="col">Cantidad</th>
        <th scope="col">Fecha</th>
    </tr>
    </thead>
    <tbody id="tabla-pedidos">
    <!-- Aquí se llenarán los pedidos dinámicamente -->
    </tbody>
</table>
    </center>
<script>
    function cargarPedidos() {
        if (!isConnected) return;
        fetch('listar_pedidos.php')
            .then(response => response.json())
            .then(pedidos => {
                const tbody = document.getElementById('tabla-pedidos');
                tbody.innerHTML = '';
                pedidos.forEach(pedido => {
                    const fila = `
                <tr>
                    <td>${pedido.id}</td>
                    <td>${pedido.producto}</td>
                    <td>${pedido.cantidad}</td>
                    <td>${pedido.fecha}</td>
                </tr>
            `;
                    tbody.innerHTML += fila;
                });
            })
            .catch(error => {
                console.error('Error al cargar pedidos:', error);
            });
    }
</script>

</body>
</html>